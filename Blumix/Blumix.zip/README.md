Blumix Edge
======

Blumix Edge: Minimal Blue-ish Mod for Numix Gtk3 Theme, it's the latest development (experimental) of Blumix

![alt tag](http://th05.deviantart.net/fs71/PRE/f/2013/319/0/e/_gtk_3_8_3_10_theme__blumix_v0_2_by_rhoconlinux-d6ubnfh.png)

Screenshots:
-----------
http://rhoconlinux.wordpress.com/2013/11/10/blumix-mod-de-numix-celestito/


*Changelog V0.5 [Dec. 2013]* 

· New Gtk2 theme, completely reworked:
	-scrollbars
	-buttons distance
	-check buttons
	-spacing on selected items
	-New menubars matching the theme
	-...all that now is coherent with the gtk3 version. 

· New GTk3 menuitem select instance
· Fixed GTk3 all the buttons and isntances with slightly rounded borders (to be continued in nautilus)
· Dark-Theme mode taken out. No further support for this is spected. 
· Bunch of other minor fixes

To-do:
This project is reaching it's first major release, with all the features about to be implemented. It still lacks work on:
Terminal scrollbars
New default Window Border
Alternative Window Borders


*Changelog V0.2 [Nov. 2013]* 

· New colored buttons and SVG assets of the theme 

· New GTk2 theme

· New menu bar, light colored

· New Dark-Theme mode

· Bunch of other minor fixes


