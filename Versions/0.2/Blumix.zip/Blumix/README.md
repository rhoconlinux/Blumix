Blumix is a Mod of Numix, but clearer and bluer :P

Description and stuff:
http://rhoconlinux.wordpress.com/wp-admin/post.php?post=744&action=edit&message=6&postpost=v2

### installation

1) Extract the zip file to the themes directory i.e. `/usr/share/themes/`

2) Apply the theme with Gnome-tweak, Ubuntu-tweak or Elementary-tweaks. 

### Manual installation



To set the theme in Gnome, run the following commands in Terminal,

```
gsettings set org.gnome.desktop.interface gtk-theme "Blumix" && gsettings set org.gnome.desktop.wm.preferences theme "Blumix"
```


More on Numix:  [Numix@GitHub](https://github.com/shimmerproject/Numix)
License: GPL-3.0+
